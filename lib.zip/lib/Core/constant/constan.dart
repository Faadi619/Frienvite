class AppConstants {
  static const String appName = "MyApp";
  static const String defaultLanguage = "en";
  static const String fromhome = "fromhome";
  static const String fromeidt = "fromedit";

  // Other constants
}
