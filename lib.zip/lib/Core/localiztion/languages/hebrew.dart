// ignore_for_file: equal_keys_in_map

class Hebrew {
  // define all static variables which will be used in all files to translate the app;
  static Map<String, String> map = {
    'Add Recipe Cover Image': 'הוסף תמונת כריכה למתכון',
    'Select Language': 'בחר שפה',
    'Add Recipe Cover Image': 'הוסף תמונת כריכה למתכון',
  };
}
